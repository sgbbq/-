﻿<?php
	
    //风轻云淡QQ692000321
	
	//列表数据删除调用	session_start(); 
	include ('conn.php');
	include ('inc/lang.php');
	mysql_query("set names utf8");
	$sql = 'select * from system';
	$res=mysql_query($sql);
	$row = mysql_fetch_array($res);
?>
<html>
<head>
<meta charset="utf-8">
<title>><?php echo $lang->admin->call;?> - <?php echo $row['title'];?></title>

<link rel="apple-touch-icon-precomposed" href="http://js.qzone.cc/v3/mobile-3.0/images/apple-touch-icon.png?_2017020304.png"/>
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/globle2014.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/style.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/wap.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/discuss.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/mb.css?v=2017020304" />
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/jquery-1.11.1.min.js?_2017020304.js"></script>
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/TouchSlide.1.1.js?_2017020304.js"></script>
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/base.js?_2017020304.js"></script>
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/mb.js?_2017020304.js"></script>
<script src="style/js/jquery.min.js"></script>
		<link rel="stylesheet" href="../style/css/bootstrap.css" crossorigin="anonymous"/>

		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
</head>
<body>
<script>
//蒙版
 if($.cookie('AppTG_3') != null){
     $(".qgTuiGuangBox").css({"visibility":"visible","bottom":"0","opacity":"1"})
     $(".qgTuiGuang").animate({
         "height":60
         ,"bottom":0
         ,"opacity":1
     },800,'fast-in',function(){$(".foot").css("padding-bottom","74px")});
 }else{
     G.indexAppTG();
 }
 if($(".qgTuiGuangBox").css("display") == "block"){
     $(".foot").css("padding-bottom","74px")
 }
</script>
<div class="container"> 
  <!--头部-->
  <div class="header">
    <div class="back_btn"><a href="/"><img src="http://js.qzone.cc/v3/mobile-3.0/images/back_btn.png"></a></div>
    <h1><?php echo $row['school'];?></h1>
    
    
  </div>
  <!--主体 个人中心-->
  <div class="main personal">
    <div class="personal_head">
      <div class="personal_head_bg"><img id="userBgImage" src="http://avatar.www.qzone.cc/wap/001/12/30/66.jpg"  onerror="this.src='http://avatar.www.qzone.cc/wap/nobg.jpg'"/></div>

      <div class="personal_head_content">

      <div class="personal_head_bg"><img id="userBgImage" src="http://avatar.www.qzone.cc/wap/000/98/77/34.jpg"  onerror="this.src='http://avatar.www.qzone.cc/wap/nobg.jpg'"/></div>
      <div class="personal_head_content">
        <div class="box01"><img src="http://q2.qlogo.cn/headimg_dl?bs=<?php echo $row['qq'];?>%E5%8F%B7&dst_uin=<?php echo $row['qq'];?>&dst_uin=<?php echo $row['qq'];?>&;dst_uin=<?php echo $row['qq'];?>&spec=100&url_enc=0&referer=bu_interface&term_type=PC" onerror="this.src='http://q2.qlogo.cn/headimg_dl?bs=<?php echo $row['qq'];?>%E5%8F%B7&dst_uin=<?php echo $row['qq'];?>&dst_uin=<?php echo $row['qq'];?>&;dst_uin=<?php echo $row['qq'];?>&spec=100&url_enc=0&referer=bu_interface&term_type=PC'" alt=""></a></div>
        <div class="box02">
        	<span>
        		<em><?php echo $row['description'];?></em>
        		        	</span>


        </div>
        <div class="box03">
                        <img src="http://js.qzone.cc/v3/mobile-3.0/images/level/200.gif" />
                  </div>

              </div>
    </div>
    <div class="nav07">
      <ul>
        <li ><a href="/index.php">首页</a></li>
        <li class="active"><a href="/call.php">表白</a></li>
        <li><a href="/search.php">查询</a></li>
        <li ><a href="/lyb.php">留言</a></li>
        <div class="clear"></div>
		<script type="text/javascript">
			function validate_required(field,alerttxt)
			{
			    with (field)
			    {
			      if (value==null||value=="")
			        {alert(alerttxt);return false}
			      else {return true}
			    }
			}
			function validate_form(thisform)
			{
			with (thisform)
			{
			    if (validate_required(content,"请填写表白内容")==false)
			    {content.focus();return false}
			}
			with (thisform)
			{
			    if (validate_required(realname,"请填写昵称")==false)
			    {realname.focus();return false}
			}
			with (thisform)
			{
			    if (validate_required(towho,"请填写表白对象")==false)
			    {towho.focus();return false}
			}
			}
		</script>
	</head>
	<body>
	<div class="bodydiv" style="margin-top: 10px;">
		<?php
		error_reporting(E_ALL^E_WARNING^E_NOTICE);
		if ($_COOKIE["userip"]=='yes'){
			echo "<script>alert('亲，五分钟内只能表白一次哦！')</script>";
			echo "<script>window.location.href='index.php'</script>";
		}
		?>
		<div class="container-fluid">
			<div class="panel panel-info">
				<div class="panel-heading" align="center">
					<h3 class="panel-title">书写出心中的那份爱</h3>
				</div>
				<div class="panel-body">
					<form name="addForm" method="post" action="sumbit.php" onsubmit="return validate_form(this)" >
						<div class="alert alert-warning" role="alert">
							<strong>使用说明：</strong></br>
							<span class="glyphicon glyphicon-ok-sign"></span>
							昵称部分请凭个人意愿填写真实姓名或者昵称</br>
							<span class="glyphicon glyphicon-ok-sign"></span>
							表白对象建议加上对方的专业班级</br>
							<span class="glyphicon glyphicon-ok-sign"></span>
							为防止刷屏，每隔5分钟可以发布一次消息
						</div>
						<div class="alert alert-danger" role="alert">
							<strong>请注意:</strong></br>
							<span class="glyphicon glyphicon-exclamation-sign"></span>
							您的IP地址为：<?php echo $_SERVER["REMOTE_ADDR"];?></br>
							<span class="glyphicon glyphicon-exclamation-sign"></span>
							现在的标准时间为：<?php date_default_timezone_set('Etc/GMT-8');  echo date("Y-m-d H:i",time()) ?></br>
							<span class="glyphicon glyphicon-exclamation-sign"></span>
							发布言论请遵守法律法规和本站管理章程
						</div>
						<input name="from" value="call" style="display: none;">
						<input name="realname" class="form-control" placeholder="昵称..." required="" autofocus="autofocus"></br>
						<input name="towho" class="form-control" placeholder="送给..." required="" autofocus=""></br>
						<textarea class="form-control" name="content" placeholder="留言内容（不超过140字）" rows="3" onkeyup='value=value.substr(0,140);this.nextSibling.innerHTML=value.length+"/140";'></textarea></br>
						<input  class="btn btn-primary btn-lg btn-block" TYPE="submit" name="submit" value="发布表白" />
					</form>
				</div>
			</div>
		</div>
	</div>
<div class="h3"></div>
		<div class="panel panel-default">
		<div class="panel-body">
			版权所有 &copy;&nbsp;<?php echo $row['footer'];?></a><br/>
			客服Q Q &copy;&nbsp;<a href="<?php echo $row['weburl'];?>" target="url"><?php echo $row['qq'];?></a></div>
		</div>
		<iframe src="" width="0px" height="0px" style="display:none;" name="url"></iframe>
		</div>
		</div>
	</body>
</html>