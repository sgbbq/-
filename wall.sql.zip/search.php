﻿<?php
 
    //风轻云淡QQ692000321
	
	//列表数据删除调用	session_start(); 
	include ('conn.php');
	include ('inc/lang.php');
	mysql_query("set names utf8");
	$sql = 'select * from system';
	$res=mysql_query($sql);
	$row = mysql_fetch_array($res);
	$searchs = $_POST['search'];
?>
<html>
<head>
<meta charset="utf-8">
<title>><?php echo $row['title'];?> - <?php echo $row['titlesm'];?></title>

<link rel="apple-touch-icon-precomposed" href="http://js.qzone.cc/v3/mobile-3.0/images/apple-touch-icon.png?_2017020304.png"/>
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/globle2014.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/style.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/wap.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/discuss.css?_2017020304.css" />
<link rel="stylesheet" type="text/css" href="http://js.qzone.cc/v3/mobile-3.0/css/mb.css?v=2017020304" />
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/jquery-1.11.1.min.js?_2017020304.js"></script>
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/TouchSlide.1.1.js?_2017020304.js"></script>
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/base.js?_2017020304.js"></script>
<script type="text/javascript" src="http://js.qzone.cc/v3/mobile-3.0/js/mb.js?_2017020304.js"></script>
<script src="style/js/jquery.min.js"></script>
		<link rel="stylesheet" href="../style/css/bootstrap.css" crossorigin="anonymous"/>

		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
</head>
<body>
<script>
//蒙版
 if($.cookie('AppTG_3') != null){
     $(".qgTuiGuangBox").css({"visibility":"visible","bottom":"0","opacity":"1"})
     $(".qgTuiGuang").animate({
         "height":60
         ,"bottom":0
         ,"opacity":1
     },800,'fast-in',function(){$(".foot").css("padding-bottom","74px")});
 }else{
     G.indexAppTG();
 }
 if($(".qgTuiGuangBox").css("display") == "block"){
     $(".foot").css("padding-bottom","74px")
 }
</script>
<div class="container"> 
  <!--头部-->
	  <div class="header">
    <div class="back_btn"><a href="/"><img src="http://js.qzone.cc/v3/mobile-3.0/images/back_btn.png"></a></div>
    <h1><?php echo $row['school'];?></h1>
    
    
  </div>
  <!--主体 个人中心-->
  <div class="main personal">
    <div class="personal_head">
      <div class="personal_head_bg"><img id="userBgImage" src="http://avatar.www.qzone.cc/wap/001/12/30/66.jpg"  onerror="this.src='http://avatar.www.qzone.cc/wap/nobg.jpg'"/></div>

      <div class="personal_head_content">

      <div class="personal_head_bg"><img id="userBgImage" src="http://avatar.www.qzone.cc/wap/000/98/77/34.jpg"  onerror="this.src='http://avatar.www.qzone.cc/wap/nobg.jpg'"/></div>
      <div class="personal_head_content">
        <div class="box01"><img src="http://q2.qlogo.cn/headimg_dl?bs=<?php echo $row['qq'];?>%E5%8F%B7&dst_uin=<?php echo $row['qq'];?>&dst_uin=<?php echo $row['qq'];?>&;dst_uin=<?php echo $row['qq'];?>&spec=100&url_enc=0&referer=bu_interface&term_type=PC" onerror="this.src='http://q2.qlogo.cn/headimg_dl?bs=<?php echo $row['qq'];?>%E5%8F%B7&dst_uin=<?php echo $row['qq'];?>&dst_uin=<?php echo $row['qq'];?>&;dst_uin=<?php echo $row['qq'];?>&spec=100&url_enc=0&referer=bu_interface&term_type=PC'" alt=""></a></div>
        <div class="box02">
        	<span>
        		<em><?php echo $row['description'];?></em>
        		        	</span>


        </div>
        <div class="box03">
                        <img src="http://js.qzone.cc/v3/mobile-3.0/images/level/200.gif" />
                  </div>

              </div>
    </div>
    <div class="nav07">
      <ul>
        <li ><a href="/index.php">首页</a></li>
        <li ><a href="/call.php">表白</a></li>
        <li class="active"><a href="/search.php">查询</a></li>
        <li ><a href="/lyb.php">留言</a></li>
        <div class="clear"></div>
<p></p>
  <div class="alert alert-success" role="alert">
		
			您搜索到<span class="badge"><?php echo $totalNumber ?></span>条表白内容
	    </div>
	    <div class="alert alert-info" role="alert">
	    	您搜索的表白对象：<?php echo $searchs;?>
	    	<a href="index.php">返回表白墙</a>
	    </div>

<?php
			$result=mysql_query("select * from list where toname ='".$searchs."'order by id desc limit 99999"); //根据前面计算出开始记录和记录数
			while ($rows=mysql_fetch_array($result)) {
		?>
	    <div class="panel panel-info">
	    	<div class="panel-heading"><strong>TO：<?=$rows[toname] ?></strong>
	        <div class="shijian"><?=$rows[lastdate]?></div>
	    </div>
	    <div class="panel-body">
	      	<p>&nbsp;&nbsp;&nbsp;&nbsp;<?=$rows[content]?></p>
	        <div class="shijian2">FROM：<?=$rows[fromname] ?></div>
	    </div>
	    </div>
	    <?php
			}
		?>
		<div class="h3" align="center">
			<a style="width: 100%;" href="index.php" class="btn btn-danger">返回表白墙首页</a>
		</div>

		<div class="panel panel-default">
		<div class="panel-body">
			版权所有 &copy;&nbsp;<?php echo $row['footer'];?></a><br/>
			客服Q Q &copy;&nbsp;<a href="<?php echo $row['weburl'];?>" target="url"><?php echo $row['qq'];?></a></div>
		</div>
		<iframe src="" width="0px" height="0px" style="display:none;" name="url"></iframe>
		</div>
		</div>
	</body>
</html>