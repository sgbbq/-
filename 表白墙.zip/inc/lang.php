﻿<?php
	//开发者昵称：颜夕
	//开发者ＱＱ：1825318987
	//版权信息：颜夕团队
	
	//前台--开始
	$lang->admin->call = '我要表白';
	$lang->admin->apply = '高校申请';
	//前台--开始
	
	//后台--开始
	$lang->admin->login = '登录';
	$lang->admin->title = '校园表白墙后台管理';
	$lang->admin->admlog = '管理员登录';
	$lang->admin->username = '管理员账号';
	$lang->admin->password = '管理员密码';
	$lang->admin->footer = 'Copyright &copy; 2017 <a href="#">校园表白墙</a> All Rights Reserved.';
	$lang->admin->goindex = '返回首页';
	
	$lang->admin->index = '后台首页';
	$lang->admin->school = '高校列表';
	$lang->admin->addschool = '添加高校';
	$lang->admin->reschool = '修改高校';
	$lang->admin->love = '表白列表';
	$lang->admin->relove = '修改表白';
	$lang->admin->system = '网站设置';
	$lang->admin->pswd = '密码修改';
	//后台--结束
	
	//综合--开始
	$lang->all->name = '校园表白墙';
	$lang->all->edition = 'V 1.0';
	$lang->all->copy = '<a href="http://fxghn.cn" target="_blank">时光团队</a>';
	//综合--结束
?>