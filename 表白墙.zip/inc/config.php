﻿<?php
	//开发者昵称：颜夕
	//开发者ＱＱ：1825318987
	//版权信息：颜夕团队

	$mysql_server_name='localhost'; //Mysql数据库服务器
	
	$mysql_username='1161661056'; //Mysql数据库用户名
	
	$mysql_password='1161661056'; //Mysql数据库密码
	
	$mysql_database='1161661056'; //Mysql数据库名

?>